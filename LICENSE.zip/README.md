# PHPSocial
PHPSocial is a simple base for other social media applications to build off of to create something amazing!

PHPSocial does not use
 - SQL
 - Any external libraries/dependencies

All it needs is
 - PHP 7.4 or later
 - 100KB of hard disk space
 - Around 8MB of ram
 - And a CPU that works and supports the latter

# ⚠ WARNING ⚠
PHPSocial is probably not the most secure web app ever, and will probably not be ready for production any time soon, it's just a fun experiment to see what can be done with just PHP =)

## How to install
See the [Setting Up](https://github.com/BreadTeleporter/PHPSocial/wiki/Setting-Up) wiki page.
